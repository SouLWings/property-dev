Parse.initialize("ad", "asd");
var G = {};

function generateCard(templateName, object){
	var template = $($(templateName).first().clone());
	template.removeClass(templateName.replace(".",""));
	var prefix = "." + template.data("prefix");//prefix = .phiddenAddress
	template.data("id", object.id);
	
	object = object.toJSON();		{hiddenAddress:"value",name:"name"}
	$.each(object, function(key, val){
		template.find(prefix+key).text(val);
	});
	
	return template;
}

function loadData(entity, callback){
	
	var Entity = Parse.Object.extend(entity);
    var query = new Parse.Query(Entity);
    query.descending("createdAt");
        
    query.find({
		success: function(results) {
			console.log("Successfully retrieved " + results.length + " "+entity+"s.");
			callback(results);
		},
		error: function(error) {
		   console.log("Error: " + error.code + " " + error.message);
		   callback(error);
		}
	});
}

/* var eat = function(param){
	if(param!==undefined)
		return param;
	return "asd";
}

alert(eat("rewq")); */

loadDataToTemplate(object, container, template)
	
	loadData(object, function(jobList){
		if(jobList.message !== undefined){
			alert(jobList.message)
			return;
		}
		var container = $(container);
		container.html("");
		if(jobList.length > 0){
			for (var i = 0; i < jobList.length; i++) {
				container.append(generateCard(template, jobList[i]));
			}
		} else {
			container.html("No data.");
		}
	}); 
}); 

function login(email, password, callback){
    Parse.User.logIn(email, password, {
        success: function(user) {
			console.log("logged in");
			if(callback != undefined)
				callback.success();
		},
        error: function(user, error) {
            console.log(error);
			callback.error(error);
		}
	});
}

function logout(){
    Parse.User.logOut();
    console.log("logged out");
}


/*
		Sample usage
		
		loadDataToTemplate("Job", '#job-list-holder', ".job-card-template");
		
		or
		
		loadData("Parent", function(parentList){
			G.parents = [];
			G.parentsJSON = [];
			var container = $('#parent_list_holder');
			container.html("");
			if(parentList.length > 0){
				for (var i = 0; i < parentList.length; i++) {
					container.append(generateCard(".parent-card-template", parentList[i]));
					G.parents.push(parentList[i]);
					G.parentsJSON.push(parentList[i].toJSON);
				}
			} else {
				container.html("No data.");
			}
		});

		object.save({
			additional_info: form.find('#additional-info').val(),
			book_before: form.find('input[name="optionsRadios"]:checked').val()
		}, {
			success: function(tutorRequest) {
		  
			},
			error: function(object, error) {
				
			}
		});

		Parse.Cloud.run('cloudFunc',{
			email: $(this).find("input[name='email']").val(),
			additional_info: form.find('#additional-info').val(),
			book_before: form.find('input[name="optionsRadios"]:checked').val()
		}, {
			success: function(results) {
				
			},
			error: function(error) {
				
			}
		});
	

	file upload
	var fileUploadControl = $("input[name='cert1']")[0];
	var parseFileCert1 = null;
	if (fileUploadControl.files.length > 0) {
		var file = fileUploadControl.files[0];
		var name = fileUploadControl.files[0].name;
   
		parseFileCert1 = new Parse.File(name, file);
	}
	
	

<!-- Template holder -->
<div id="templates_holder" class='hidden'>

	<div class="col-sm-12 col-md-12 parent-card parent-card-template" data-prefix="p">
		<section class="panel">
			<header class="panel-heading st-red" style="color: white;"> 
				<span class='ptitle searchable'>Dr </span> 
				<span class='pname searchable'>Khamis Bin Jumaat</span>
			</header>
			<div class="panel-body">
				<div class='parent_info searchable'>
					<div class='pphone searchable'>
						01115134217
					</div>
					<div class='pemail searchable'>
						admin@etuition.com.my
					</div>
					<div class='phiddenAddress searchable'>
						123, JLN Mati, Pulau Pinang
					</div>
					<div class='premarks searchable'>
						This 1 owez ffk
					</div>
				</div>
			</div>
		</section>
	</div>
	
	
	
</div>	
	
*/	   
